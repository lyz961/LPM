package com.example.concesionario_sabado;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText jetidentificacion, jetnombre,jetidentificacion,jettelefono;

    CheckBox jcbactivo;
    CheckBox jcbactivo;
    Button
    ClsOpenHelper ADMIN= new ClsOpenHelper(context:this,name:"CONCESIONARIO.db",factory:null, version 1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente);
        //OCULTAR LA BARRA DE TITULO POR DEFECTO
        getSupportActionBar().hide();
        //ASOCIAR OBJETOS JAVA A OBJETOS XML
        jetidentificacion=findViewById(R.id.etidentificacion);
        jetnombre=findViewById(R.id.etnombre);
        View jetdirección = findViewById(R.id.etdirección);
        jettelefono=findViewById(R.id.ettelefono);
        jcbactivo=findViewById(R.id.cbactivo);
        jetidentificacion.requestFocus();
        //SQLiteDatabase db=ADMIN.getReadableDatabase()//
    }
    public void clientes Intent createPackageContext;
        Intent intclientes;
        (View){
   Intent intclientes=new Intent( createPackageContext: this, ClienteActivity.class)
        startActivity (intclientes);
        public class MainActivity extends AppCompatActivity {

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

            } }