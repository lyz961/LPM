package com.example.concesionario_sabado;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ClsOpenHelper extends SQLiteOpenHelper {
    public ClsOpenHelper() {
        super(context,name,factory,version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table TblCliente (Ident_Cliente text primary key,Nom_Cliente text not null, Dir_Cliente text not null, Tel_Cliente text not null, Modelo text not null, Activo text default´Si`, constraint pk_factura foreign key (Ident_Cliente) references TbCliente (Ident_Cliente)");
    db.execSQL("create table TblFactura (Cod_Factura text primary key, fecha text not null, Ident_Cliente text not null, Activo text,default´Si`, constrait pk_Factura foreign key (Indet_Cliente ), references TblCliente (Id_Cliente))");
    db.execSQL("create table TblDetalle_Factura (Cod_Factura text not null);Placa text not null, Valor_Venta integer not null, constrain pk_detalle primary key (Cod_Factura,Placa), foreign key (Cod_Factura) references Tbl_Factura (Cod_Factura)Foreign key (Placa) references Tbl_Vehiculo (Placa)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       db.execSQL("Drop table TblDetalle_Factura");
       db.execSQL("Drop table TblFactura");
       db.execSQL("Drop table TblVehiculo");
       db.execSQL("Drop table TblCliente");
        { onCreate(db);
    }
}
}
